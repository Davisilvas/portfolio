# Seja bem-vindo ao meu portfólio!

<h1>Sobre</h1>
<p> Neste projeto desenvoli uma landing page onde o intuito dela é demonstrar as tecnologias que eu domino atualmente e também ter uma seção onde eu exponho alguns de meus projetos que fiz com fins de estudo e também meus trabalhos. Neste projeto também será possível encontrar as melhores formas de entrar em contato comigo.</p>

<p>Para visitar meu portifólio basta acessar <a href="https://davisantos.dev.br" target="_blank">davisantos.dev.br</a>!</p>

<p>Segue o gif com uma breve apresentação do projeto!</p>
<img src="./assets/images/desktop_gif.gif">
<br><br><br>
<h1>Um pouco mais sobre o projeto...</h1>
<p>Para este projeto, resolvi a primeiro momento desenvolver ele usando a santíssima triade do front-end! Nele você vai encontrar código em HTML, CSS e JavaScript. Mas isso pode mudar a qualquer momento comigo enfrentando o desafio de reinventar esse projeto! O que não vai demorar muito para acontecer😅</p>
